﻿using LiteNetLib;
using LiteNetLib.Utils;
using System.Collections;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;


public class Test 
{
    public class ClientListener : INetEventListener
    {
        public bool isConnected = false;
        public NetManager client;
        public NetPeer netPeer;
        public bool connecting = false;

        public void OnPeerConnected( NetPeer peer )
        {
            connecting = false;
            isConnected = true;
            netPeer = peer;
        }

        public void OnPeerDisconnected( NetPeer peer , DisconnectInfo disconnectInfo )
        {
            isConnected = false;
            connecting = false;
        }

        public void OnNetworkError( IPEndPoint endPoint , SocketError socketErrorCode )
        {
        }

        public void OnNetworkReceive( NetPeer peer , NetPacketReader reader , DeliveryMethod deliveryMethod )
        {
            reader.Recycle();
        }

        public void OnNetworkReceiveUnconnected( IPEndPoint remoteEndPoint , NetPacketReader reader , UnconnectedMessageType messageType )
        {
            reader.Recycle();
        }

        public void OnNetworkLatencyUpdate( NetPeer peer , int latency )
        {

        }

        public void OnConnectionRequest( ConnectionRequest request )
        {
            isConnected = true;
        }
    }

    ClientListener clientListener;
    NetDataWriter dataWriter = new NetDataWriter( false , 1024 );


    public Test()
    {
        clientListener = new ClientListener();

        NetManager client1 = new NetManager( clientListener )
        {
            SimulationMaxLatency = 1500 ,
        };
        if ( !client1.Start() )
        {
            return;
        }

        clientListener.client = client1;
    }

    float time = 0f;

    // Update is called once per frame
    public void Update( float delay )
    {
        if ( clientListener.client != null )
        {
            if ( clientListener.isConnected )
            {
                time += delay;
                float fps = 0.05f;

                if ( time > fps )
                {
//                     time -= fps; // in some cpu may error.
                    time = 0f;

                    dataWriter.Reset();
                    dataWriter.Put( 123 );
                    clientListener.netPeer.Send( dataWriter , DeliveryMethod.Unreliable );
                }
            }
            else
            {
                if ( !clientListener.connecting )
                {
                    clientListener.connecting = true;
                    clientListener.client.Connect( "192.168.2.77" , 5666 , "X" );
//                    clientListener.client.Connect( "119.28.52.146" , 5666 , "X" );
                }
            }

            clientListener.client.PollEvents();
        }

    }
}
