using System.Collections;
using System.Net.Sockets; 
using System.Net; 
using System.Threading;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System;


public class TestSocket
{
	private System.Net.Sockets.Socket socket;
	private bool connected = false;

	public string serverIP;
	public int serverPort;
	public int bufferSize = 10240;
	public int timeOut = 5000;

    float time = 0f;

    public TestSocketIOBuffer iBuffer;
	public TestSocketIOBuffer oBuffer;

    public bool IsConnected
    {
        get
        {
            return connected;
        }
    }

    public TestSocket()
	{
        iBuffer = new TestSocketIOBuffer();
		iBuffer.InitBuffer( bufferSize );
		oBuffer = new TestSocketIOBuffer();
		oBuffer.InitBuffer( bufferSize );
	}

	public bool Connect( string ip , int port )
	{
		serverIP = ip;
		serverPort = port;

		if ( serverIP.Length == 0 ) 
		{
            return false;
		}

		bool ipV6 = false;

		IPAddress ipAddress = null;
		try
		{
			IPHostEntry dnstoip = new IPHostEntry();           

			IPAddress[] ipHostInfo = Dns.GetHostAddresses( ip ); 
			ipAddress = ipHostInfo[ 0 ]; 

		}
		catch ( Exception ex ) 
		{
			socket = null;
			connected = false;

            return false;
		}

		if ( socket == null )
		{
            socket = new System.Net.Sockets.Socket ( ipV6 ? AddressFamily.InterNetworkV6 : AddressFamily.InterNetwork , SocketType.Dgram , ProtocolType.Udp );
		}

		socket.Blocking = true;

		IPEndPoint ipEndpoint = new IPEndPoint( ipAddress , port );

		try 
		{
			socket.Connect( ipEndpoint );
		}
		catch ( Exception ex ) 
		{
			socket = null;
			connected = false;

            return false;
		}

		socket.Blocking = false;

		connected = socket.Connected;

        return true;
	}

	public void	Close()
	{
		if ( !connected )
		{
			return;
		}

		try 
		{
			socket.Shutdown( SocketShutdown.Both );
		}
		catch ( Exception ) 
		{}

		socket.Close();
		socket = null;

		connected = false;

		iBuffer.ClearBuffer();
		oBuffer.ClearBuffer();
	}


	public void SendData()
	{
		int len = oBuffer.GetLen();

		if ( len == 0 )
		{
			return;
		}

		if ( socket == null )
		{
			return;
		}

		SocketError error = SocketError.Success;
		int tmp = socket.Send( oBuffer.GetBuffer() , oBuffer.GetOffset() , len , SocketFlags.None , out error );

		if ( tmp <= 0 )
		{
			if ( error == SocketError.NoBufferSpaceAvailable || 
				error == SocketError.Interrupted || 
				error == SocketError.Success ||
				error == SocketError.WouldBlock  )
			{
				return;
			}
			else
			{
				Close();

				return;
			}
		}

		oBuffer.RemoveBuffer( tmp );
	}


	public void RecvData()
	{
		if ( iBuffer.GetSpace() < 1024 )
		{
			return;
		}

		if ( socket == null )
		{
			return;
		}

		SocketError error;
		int count = socket.Receive( iBuffer.GetBuffer() , iBuffer.GetOffset() + iBuffer.GetLen() , iBuffer.GetSpace() , SocketFlags.None , out error );

		if ( count > 0 )
		{
// 			iBuffer.Write( count );   
		}
		else if ( count <= 0 )
		{
			if ( error == SocketError.NoBufferSpaceAvailable || 
				error == SocketError.Interrupted || 
				error == SocketError.Success ||
				error == SocketError.WouldBlock )
			{
				// No data available to read (and socket is non-blocking)
				count = 0;
			}
			else
			{
				Close();

				return;
			}
		}
	}

	public void Update( float delay )
	{
		if ( !connected )
		{
            if ( Connect( "192.168.2.77" , 5666 ) )
            {
                SendConnect();
                SendData();
            }
            
			return;
		}

        time += delay;
        float fps = 0.05f;

        if ( time > fps )
        {
            time = 0f;
            SendMsg();
        }

        SendData();
		RecvData();
	}
	
    public void SendConnect()
    {
    }

    public void SendMsg()
	{
		oBuffer.ClearBuffer();
		oBuffer.Write( BitConverter.GetBytes( (byte)0 ) , 1 );
        oBuffer.Write( BitConverter.GetBytes( 123 ) , 4 );
    }




}
