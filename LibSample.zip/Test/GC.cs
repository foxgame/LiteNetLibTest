﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class GC
{
    float time = 0f;

    public long lastMemory = 0;
    public int lastGCCount = 0;

    long memoryAll = 0;
    int sec = 0;

    bool first = false;

    public void Update( float delay )
    {
        time += delay;

        if ( time > 1f )
        {
            time = 0f;
            sec++;

            if ( !first )
            {
                first = true;
                lastMemory = System.GC.GetTotalMemory( false );
                lastGCCount = System.GC.CollectionCount( 0 );
            }

            long memory = System.GC.GetTotalMemory( false );
            int count = System.GC.CollectionCount( 0 );

            Console.WriteLine( "m: " + ( memory - lastMemory ) / 1024f +
                 " tm: " + memory / 1024f + 
                 " a: " + memoryAll / sec / 1024f + 
                 " c: " + ( count - lastGCCount )  +
                " tc: " + count );;

            memoryAll += ( memory - lastMemory );

            lastMemory = memory;
            lastGCCount = count;
        }
    }
}