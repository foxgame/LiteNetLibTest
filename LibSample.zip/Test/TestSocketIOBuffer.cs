using System.Runtime;
using System.Collections;
using System.Runtime.InteropServices;



[ StructLayout( LayoutKind.Sequential , Pack = 1 ) ]
public struct TestSocketIOBuffer
{
	int begin;
	int len;
	
	byte[] buffer;
	int maxLen;
	
	
	public void	ClearBuffer()
	{
		begin = 0;
		len = 0;
	}
	
	
	public void	InitBuffer( int m )
	{
		maxLen = m;
		
		if ( buffer == null )
		{
			buffer = new byte[ m ];
		}
		
		begin = 0;
		len = 0;
	}
	
	
	public void	ReleaseBuffer()
	{
		begin = 0;
		len = 0;
		maxLen = 0;
		buffer = null;
	}
	
	public void	Write( int l )
	{
		len += l;
	}
	
	public void	RemoveBuffer( int l )
	{
		if ( len < l ) 
		{
			return;
		}
		
		begin += l;
		len -= l;
		
		if ( len == 0 ) 
		{
			begin = 0;
		}
	}
	
	public bool Write( byte[] b , int l )
	{
		if ( GetSpace() < l )
		{
			return false;
		}
		
		for ( int i = 0 ; i < l ; i++ )
		{
			buffer[ i + begin + len ] = b[ i ];
		}

		len += l;
		
		return true;
	}
	
	public int GetLen()
	{
		return len;
	}
	
	public int GetOffset()
	{
		return begin;
	}
	
	public int GetSpace()
	{
		return maxLen - begin - len;
	}
	
	public byte[] GetBuffer()
	{
		return buffer;
	}


	
}

