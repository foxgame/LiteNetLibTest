using System;
using System.Text;
using System.Threading;

namespace LibSample
{
    public static class Program
    {
        public static bool running = true;

        public static long lastTime;
        public static float timeDelay = 0f;
        public static Test test = new Test();
        public static TestSocket testSocket = new TestSocket();
        public static GC gc = new GC();


        static long GetTime()
        {
            return ( DateTime.Now.ToUniversalTime().Ticks - 621355968000000000 );
        }

        static void Run()
        {
            long time = GetTime();
            timeDelay = (float)( ( time - lastTime ) / 10000000.0 );

//              testSocket.Update( timeDelay );
//           test.Update( timeDelay );
            gc.Update( timeDelay );

            Thread.Sleep( 1 );

            lastTime = time;
        }

        static void Main(string[] args)
        {
            while ( running )
            {
                Run();
            }
        }
    }
}

